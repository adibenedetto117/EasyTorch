#from .cnn import CNN
#from .rnn import YourRNNClass
#from .lstm import YourLSTMClass
from .main import quicktorch